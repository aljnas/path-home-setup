#!/bin/bash
clear
echo "🏠 PATH Setup: Seguridad inicial del nuevo hogar"
echo "--------------------------------------------------"
echo "🔧 Este script te guiará en el primer paso técnico tras mudarte."
echo ""
sleep 1

echo "✅ Paso 1: Proteger la red WiFi"
echo "Recomendación: Ejecuta el asistente interactivo:"
echo "./wifi_protect_assistant.sh"
echo ""

echo "✅ Paso 2: Configurar los dispositivos principales"
echo "• Laptop nueva (Windows)"
echo "• Dispositivos móviles (Android / iOS)"
echo "• Linux (si aplica)"
echo ""

echo "📍 Próximos pasos sugeridos:"
echo "1. Crear usuarios sin privilegios para uso diario"
echo "2. Instalar navegador seguro (Brave, Firefox)"
echo "3. Activar autenticación en dos pasos (2FA)"
echo "4. Instalar antivirus (Windows Defender, Bitdefender Free)"
echo "5. Crear carpeta encriptada para documentos personales"
echo ""

echo "Para más seguridad, ejecutar los siguientes scripts:"
echo "  ./setup_windows_user.sh"
echo "  ./setup_android.sh"
echo "  ./setup_linux.sh"
echo ""

echo "🧩 Este script es la piedra base del despliegue técnico en tu nuevo hogar. ✨"
