#!/bin/bash
echo "📱 PATH Setup: Seguridad inicial para iOS (iPhone/iPad)"
echo "--------------------------------------------------------"
echo "1. Activar Face ID o contraseña fuerte"
echo "2. Revisar actualizaciones del sistema"
echo "3. Revisar apps con acceso a cámara, micrófono y ubicación"
echo "4. Activar autenticación en dos pasos para iCloud"
echo "5. Safari: activar bloqueo de rastreo cruzado y prevenir seguimiento"
