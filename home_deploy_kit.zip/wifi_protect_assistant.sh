#!/bin/bash
clear
echo "🔐 Asistente interactivo para proteger tu red WiFi en casa [Automatizado]"
echo "------------------------------------------------------------"
sleep 1

# Paso 1: Cambio de credenciales
echo ""
read -p "1. ¿Cambiaste el nombre y la contraseña por defecto del router? (sí/no): " paso1
if [[ "$paso1" == "no" ]]; then
  echo "👉 Abre tu navegador y entra en http://192.168.1.1 o http://192.168.0.1"
  echo "🔑 Busca 'Admin Settings' y cambia usuario/contraseña de acceso al router."
  echo "    ⚠️ Consejo: Usa un administrador de contraseñas y evita 'admin/admin'."
fi

# Paso 2: WPA3
echo ""
read -p "2. ¿El router tiene activado el cifrado WPA3 o al menos WPA2-AES? (sí/no): " paso2
if [[ "$paso2" == "no" ]]; then
  echo "👉 Entra en configuración inalámbrica del router (Wireless > Security)"
  echo "    📌 Cambia el tipo de seguridad a WPA3 o WPA2-AES si tu router lo soporta."
fi

# Paso 3: WPS
echo ""
read -p "3. ¿Está desactivado WPS? (sí/no): " paso3
if [[ "$paso3" == "no" ]]; then
  echo "⚠️ WPS facilita ataques. Desactívalo desde la sección de WiFi Protected Setup (WPS)."
fi

# Paso 4: IP acceso router
echo ""
read -p "4. ¿Cambiaste la IP de acceso del router (por defecto 192.168.0.1)? (sí/no): " paso4
if [[ "$paso4" == "no" ]]; then
  echo "🛠️ Ve a LAN Settings y cambia la IP a algo como 10.0.0.1 para dificultar ataques automatizados."
fi

# Paso 5: Ocultar SSID
echo ""
read -p "5. ¿Está el SSID oculto? (sí/no): " paso5
if [[ "$paso5" == "no" ]]; then
  echo "👻 Ocultar el SSID no es seguridad fuerte, pero evita que aparezcas como red visible."
  echo "    Configura esto en 'Wireless Settings' > 'SSID Broadcast': Disable."
fi

# Paso 6: Firewall
echo ""
read -p "6. ¿Está activado el firewall del router? (sí/no): " paso6
if [[ "$paso6" == "no" ]]; then
  echo "🧱 Entra a configuración avanzada del router y busca 'Firewall' o 'SPI Firewall'. Actívalo."
fi

# Paso 7: Dispositivos conectados
echo ""
read -p "7. ¿Revisaste los dispositivos conectados a tu red? (sí/no): " paso7
if [[ "$paso7" == "no" ]]; then
  echo "🔍 Puedes usar herramientas como 'arp-scan' en Linux o apps como Fing en Android/iOS."
  echo "    También puedes revisar la tabla DHCP en tu router."
fi

echo ""
echo "🎯 Proceso finalizado. Revisa los pasos que marcaste como 'no' y sigue las instrucciones dadas."
